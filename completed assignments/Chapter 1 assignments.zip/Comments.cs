using System;
class Comments
{
	static void main()
	{ 
		// This is a line comment
			Console.WriteLine("For this question, i have to write a comment");
		/* This shin dig is like the bomb diggedy */
	}
}
