﻿using System;
class BigLetter
{
    static void Main()
    {
        Console.WriteLine("H      H");
        Console.WriteLine("H      H");
        Console.WriteLine("H      H");
        Console.WriteLine("HHHHHHHH");
        Console.WriteLine("H      H");
        Console.WriteLine("H      H");
        Console.WriteLine("H      H");
        Console.ReadLine();
    }
}
