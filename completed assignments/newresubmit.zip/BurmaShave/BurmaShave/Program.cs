﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("One pound 85 cents");
            Console.WriteLine("Half pound 50 cents");
            Console.WriteLine("Big tube 35 cen ts");
            Console.WriteLine("Don't put it off"); 
            Console.WriteLine("Put it on");
            Console.ReadLine();
        }
    }
}

