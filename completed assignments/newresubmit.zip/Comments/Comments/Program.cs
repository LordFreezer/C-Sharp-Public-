﻿using System;                 /* Chad Marshall*/
class Comments
{
    static void Main()
    {
        // This is a line comment
        Console.WriteLine("For this question, i have to write a comment");
        /* This shin dig is like the bomb diggedy */
    }
}
