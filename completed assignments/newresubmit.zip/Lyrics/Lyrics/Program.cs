﻿using System;
class Lyrics
{
    static void Main()
    {
        Console.WriteLine("You guys do not notice that we");
        Console.WriteLine("are gifted just by being humans");
        Console.WriteLine("We are absolute predators");
        Console.WriteLine("We do not even have any enemies Maybe there are other animals watching us and thinking that someday we will beat them down");
        Console.ReadLine();
    }
}
